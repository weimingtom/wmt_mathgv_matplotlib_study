<?php
echo "hello\n";
?>



